var group___core_a_p_i =
[
    [ "Touch Event", "group___touch_event.html", "group___touch_event" ],
    [ "NexObject", "class_nex_object.html", [
      [ "NexObject", "class_nex_object.html#ab15aadb9c91d9690786d8d25d12d94e1", null ],
      [ "printObjInfo", "class_nex_object.html#abeff0c61474e8b3ce6bac76771820b64", null ]
    ] ],
    [ "NexUpload", "class_nex_upload.html", [
      [ "NexUpload", "class_nex_upload.html#a017c25b02bc9a674ab5beb447a3511a0", null ],
      [ "NexUpload", "class_nex_upload.html#a97d6aeee29cfdeb1ec4dcec8d5a58396", null ],
      [ "~NexUpload", "class_nex_upload.html#a26ccc2285435b6b573fa5c4b661c080a", null ]
    ] ],
    [ "nexInit", "group___core_a_p_i.html#gab09ddba6b72334d30ae091a7b038d790", null ],
    [ "nexLoop", "group___core_a_p_i.html#ga91c549e696b0ca035cf18901e6a50d5a", null ]
];